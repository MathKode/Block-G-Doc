if (confirm("Vous voulez vraiment ouvrir ce word ?")) {
  //alert("You pressed OK!");
} else {
  //alert("You pressed Cancel!");
  window.close();
}
